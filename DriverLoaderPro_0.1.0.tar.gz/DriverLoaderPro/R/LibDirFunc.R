getLibDir <- function() {
  return(system.file('extdata/drivers/libjvm.dylib', package='DriverLoaderPro'))
}
