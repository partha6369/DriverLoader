installGit <- function() {
  devtools::install_github("partha6369/DriverLoaderPro", auth_token = "be2e83d95e6acef2bdb3906ca809c543f4af0325")
}
